package com.StudySpring.Springsession1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSession1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
